class invalidPython(Exception):
    """ Exception raised for illegal python files """
    pass

class illegalImport(Exception):
    """ Exception raised for illegal imports."""
    pass
